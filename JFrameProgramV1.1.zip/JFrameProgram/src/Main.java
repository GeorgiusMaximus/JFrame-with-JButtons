import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Random random = new Random();
        JButton button = new JButton("close window");
        JButton otherWindowButton = new JButton("open another window");
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
                System.out.println("close window pressed");
            }
        });

        panel.add(button);
        panel.add(otherWindowButton);
        otherWindowButton.setBounds(330, 25, 200, 25);
        otherWindowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame otherFrame = new JFrame();
                JLabel otherFramesLabel = new JLabel();
                otherFrame.add(otherFramesLabel);
                otherFramesLabel.setLayout(null);
                otherFramesLabel.setText("Now I´m here");
                otherFrame.setSize(250, 100);
                otherFrame.setLocationRelativeTo(null);
                otherFrame.setResizable(false);
                otherFrame.setVisible(true);
                System.out.println("open another window pressed");
            }
        });
        panel.setLayout(null);
        button.setBounds(220, 150, 140, 50);
        panel.setVisible(true);
        frame.add(panel);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
